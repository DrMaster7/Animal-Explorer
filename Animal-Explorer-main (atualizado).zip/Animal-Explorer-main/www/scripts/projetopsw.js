"use strict";

// Funções de navegação para aceder de uma página para outra.
window.showLoginToSignup = () => {
    document.getElementById("loginPage").classList.remove("active");
    document.getElementById("signupPage").classList.add("active");
};

window.showSignupToLogin = () => {
    document.getElementById("signupPage").classList.remove("active");
    document.getElementById("loginPage").classList.add("active");
};

window.showLoginToMain = () => {
    document.getElementById("loginPage").classList.remove("active");
    document.getElementById("mainPage").classList.add("active");
}

window.showMainToLogin = () => {
    document.getElementById("mainPage").classList.remove("active");
    document.getElementById("loginPage").classList.add("active");
};

window.showMainToDashboard = () => {
    document.getElementById("mainPage").classList.remove("active");
    document.getElementById("dashboardPage").classList.add("active");
}

window.showDashboardToMain = () => {
    document.getElementById("dashboardPage").classList.remove("active");
    document.getElementById("mainPage").classList.add("active");
}

// Registo
window.handleSignup = (event) => {
    event.preventDefault();
    var name = document.getElementById("signupName").value;
    var email = document.getElementById("signupEmail").value;
    var password = document.getElementById("signupPassword").value;
    var confirm = document.getElementById("signupConfirm").value;
    if (password !== confirm) {
        alert("As palavras-passes não combinam.");
        return;
    }
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "/signup", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            alert("Registo bem-sucedido.");
            window.showSignUpToLogin();
        } else if (xhr.readyState === 4) {
            alert("Erro no registo: " + xhr.responseText);
        }
    };
    xhr.send(JSON.stringify({ name: name, email: email, password: password }));
}

// Login
window.handleLogin = (event) => {
    event.preventDefault();
    var email = document.getElementById("loginEmail").value;
    var password = document.getElementById("loginPassword").value;
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "/login", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            alert("Login bem-sucedido.");
            window.showLoginToMain();
        } else if (xhr.readyState === 4 && xhr.status === 401) {
            alert("Dados inseridos incorretamente.");
        } else if (xhr.readyState === 4) {
            alert("Erro no login: " + xhr.responseText);
        }
    };
    xhr.send(JSON.stringify({ email: email, password: password }));
}

// Logout
window.handleLogout = () => {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "/logout", true); 
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            alert("Logout bem-sucedido.");
            window.showMainToLogin();
        } else if (xhr.readyState === 4) {
            alert("Erro no logout: " + xhr.responseText);
        }
    };
    xhr.send(); 
};

// Verificar sessão existente
window.loginStatus = () => {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "/check-session", true); 
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) { // Se existir uma sessão ativa
                const response = JSON.parse(xhr.responseText);
                console.log(`Bem-vindo de volta, ${response.user.user_name}`);
                alert("Bem-vindo de volta.")
                window.showLoginToMain(); 
            } else if (xhr.status === 401) { // Se não existir uma sessão ativa
                console.log("Sem sessão, a mostrar ecrã de login.");
                window.showMainToLogin();
            } else { // Caso exista alguma falha
                console.error("Erro ao verificar sessão: " + xhr.responseText);
                window.showMainToLogin(); // Redireciona diretamente para o login.
            }
        }
    };
    xhr.send();
};

// Detalhes das especies

const SPECIES_DATA = {
  'Mammals': [
    { name: 'Lion', img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/73/Lion_waiting_in_Namibia.jpg/400px-Lion_waiting_in_Namibia.jpg' },
    { name: 'Elephant', img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f1/African_Elephant_%28Loxodonta_africana%29_male_%2831755979696%29.jpg/400px-African_Elephant_%28Loxodonta_africana%29_male_%2831755979696%29.jpg' },
    { name: 'Dog', img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/36/Golden_retriever_standing_Tucker.jpg/400px-Golden_retriever_standing_Tucker.jpg' },
    { name: 'Cat', img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Cat03.jpg/400px-Cat03.jpg' },
    { name: 'Bear', img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6b/American_Black_Bear_%2819092155893%29.jpg/400px-American_Black_Bear_%2819092155893%29.jpg' },
    { name: 'Wolf', img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5f/Gray_wolf_in_British_Columbia.jpg/400px-Gray_wolf_in_British_Columbia.jpg' }
  ],
  'Birds': [
    { name: 'Eagle', img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/19/Bald_Eagle_%28Haliaeetus_leucocephalus%29_%28514630612%29.jpg/400px-Bald_Eagle_%28Haliaeetus_leucocephalus%29_%28514630612%29.jpg' },
    { name: 'Parrot', img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Scarlet_Macaw_%28Ara_macao%29_%282%29.jpg/400px-Scarlet_Macaw_%28Ara_macao%29_%282%29.jpg' },
    { name: 'Owl', img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Great_Horned_Owl_%28Bubo_virginianus%29_%282%29.jpg/400px-Great_Horned_Owl_%28Bubo_virginianus%29_%282%29.jpg' }
  ],
  'Reptiles': [
    { name: 'Crocodile', img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Nile_crocodile_%28Crocodylus_niloticus%29_head.jpg/400px-Nile_crocodile_%28Crocodylus_niloticus%29_head.jpg' },
    { name: 'Turtle', img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1e/Green_Sea_Turtle_grazing_seagrass.jpg/400px-Green_Sea_Turtle_grazing_seagrass.jpg' },
    { name: 'Snake', img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Black_mamba_%28Dendroaspis_polylepis%29.jpg/400px-Black_mamba_%28Dendroaspis_polylepis%29.jpg' }
  ],
  'Amphibians': [
    { name: 'Frog', img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3b/Rana_temporaria_%28cropped%29.jpg/400px-Rana_temporaria_%28cropped%29.jpg' },
    { name: 'Salamander', img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Tiger_Salamander_%28Ambystoma_tigrinum%29.jpg/400px-Tiger_Salamander_%28Ambystoma_tigrinum%29.jpg' },
    { name: 'Newt', img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Smooth_newt_%28Lissotriton_vulgaris%29.jpg/400px-Smooth_newt_%28Lissotriton_vulgaris%29.jpg' }
  ],
  'Fish': [
    { name: 'Shark', img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/35/Great_white_shark_south_africa.jpg/400px-Great_white_shark_south_africa.jpg' },
    { name: 'Clownfish', img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/31/Amphiprion_ocellaris_%28Clown_anemonefish%29_in_Heteractis_magnifica_%28Magnificent_sea_anemone%29.jpg/400px-Amphiprion_ocellaris_%28Clown_anemonefish%29_in_Heteractis_magnifica_%28Magnificent_sea_anemone%29.jpg' },
    { name: 'Tuna', img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Atlantic_bluefin_tuna.jpg/400px-Atlantic_bluefin_tuna.jpg' }
  ],
  'Insects': [
    { name: 'Butterfly', img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Monarch_Butterfly_Danaus_plexippus_Feeding_Durham_NC_2735.jpg/400px-Monarch_Butterfly_Danaus_plexippus_Feeding_Durham_NC_2735.jpg' },
    { name: 'Bee', img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0e/Honey_bee_on_a_dandelion%2C_Sandy%2C_Bedfordshire_%2826585751974%29.jpg/400px-Honey_bee_on_a_dandelion%2C_Sandy%2C_Bedfordshire_%2826585751974%29.jpg' },
    { name: 'Ladybug', img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f2/Coccinella_magnifica_%28Red_seven-spot_ladybird%29.jpg/400px-Coccinella_magnifica_%28Red_seven-spot_ladybird%29.jpg' }
  ]
};

window.showSpeciesDetail = (species) => {
  currentSpecies = species;
  document.getElementById('speciesHeaderTitle').textContent = species;
  document.getElementById('speciesContentTitle').textContent = species;

  const grid = document.getElementById('animalGrid');
  grid.innerHTML = '';

  const animals = SPECIES_DATA[species] || [];

  animals.forEach(animal => {
    const card = document.createElement('div');
    card.className = 'animal-card';
    card.onclick = () => showAnimalProfile(animal);
    card.innerHTML = `
      <div class="animal-image" style="background-image: url('${animal.img}');"></div>
      <div class="animal-name">${animal.name}</div>
    `;
    grid.appendChild(card);
  });

  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById('speciesDetailPage').classList.add('active');
};


/**
 * Será executada quando a página for carregada, criando a variável "info" e um objeto Information.
 * Irá também pedir ao servidor o carregamento dos dados de forma síncrona (AJAX).
 * @memberof window
 * @params {Event} event - objeto que representará o evento
 */

/*
window.onload = (event) => {
    var info = new Information("divInformation");
    info.getUser();
    info.getAnimal();
    info.getLogs();
    window.info = info;
    window.loginStatus();
};
*/

/** 
* @class Guarda toda informação necessaria na execução do exercicio 
* @constructs Informacao
* @param {string} id - id do elemento HTML que contém a informação.
* 
* @property {string} id - id do elemento HTML que contém a informação.
* @property {sensor[]} sensors - Array de objetos do tipo Sensor, para guardar todos os users do nosso sistema
*/

/*
class Information {
    constructor(id) {
        this.id = id;
        this.user=[];
    }
}
*/